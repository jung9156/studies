import requests
from bs4 import BeautifulSoup
import json
import sys
from collections import OrderedDict

# print(data)
# print(soup.find_all('item'))
clsfc_namelist = {"11": "국보", "12": "보물", "13": "사적", "14": "사적및명승", "15": "명승", "16": "천연기념물", "17": "국가무형문화재", "18": "국가민속문화재", "21": "시도유형문화재", "22": "시도무형문화재", "23": "시도기념물", "24": "시도민속문화재", "31": "문화재자료", "79": "등록문화재", "80": "이북5도무형문화재"}
heritage_data = OrderedDict()
for pagenum in range(797, 798):
    data = requests.get(f"http://www.cha.go.kr/cha/SearchKindOpenapiList.do?pageUnit=20&pageIndex={pagenum}")
    soup = BeautifulSoup(data.content, "xml")
    for i in soup.find_all("item"):
        selnum = i.ccbaAsno.text
        k_name = i.ccbaMnm1.text
        h_name = i.ccbaMnm2.text
        clsfc_code = i.ccbaKdcd.text
        clsfc_name = clsfc_namelist[clsfc_code]
        longitude = i.longitude.text
        latitude = i.latitude.text
        
        sidocode = i.ccbaCtcd.text
        datadetail = requests.get(f"http://www.cha.go.kr/cha/SearchKindOpenapiDt.do?ccbaKdcd={clsfc_code}&ccbaAsno={selnum}&ccbaCtcd={sidocode}")
        soup2 = BeautifulSoup(datadetail.content, "xml")
        
        content = soup2.content.text
        imageURL = soup2.imageUrl.text
        era = soup2.ccceName.text
        address = soup2.ccbaLcad.text.strip()
        heritage_data[selnum] = {"selnum": selnum, "k_name": k_name, "h_name": h_name, "clsfc_code": clsfc_code, "clsfc_name": clsfc_name, "longitude": longitude, "latitude": latitude, "content": content, "imageURL": imageURL, "era": era, "address": address}

# print(heritage_data)

# print(json.dumps(heritage_data, sort_keys=True, indent=4))
with open("heritage_data1.json", "w", encoding="utf-8") as make_file:
    json.dump(heritage_data, make_file, ensure_ascii=False, indent="\t")